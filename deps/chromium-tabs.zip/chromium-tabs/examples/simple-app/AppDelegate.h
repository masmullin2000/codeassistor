#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate> {
}

- (void)commandDispatch:(id)sender;

@end
