#import <ChromiumTabs/ChromiumTabs.h>

// This class represents a tab. In this example application a tab contains a
// simple scrollable text area.
@interface MyTabContents : CTTabContents {
}

@end
